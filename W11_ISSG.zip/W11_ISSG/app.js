const express = require('express');
const session = require('express-session');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

const app = express();
const port = 3000;

// Middleware for session management
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: true
}));

// Set view engine to EJS
app.set('view engine', 'ejs');

// Initialize Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Configure Google OAuth strategy
passport.use(
    new GoogleStrategy(
        {
            clientID: "204881965548-q31mash0bm1ppsm761hr7k6bann0f0g2.apps.googleusercontent.com",
            clientSecret: "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",
            callbackURL: "http://localhost:3000/auth/google/callback"
        },
        (accessToken, refreshToken, profile, done) => {
            // Return the user's profile after authentication
            return done(null, profile);
        }
    )
);

// Serialize user into session
passport.serializeUser((user, done) => {
    done(null, user);
});

// Deserialize user from session
passport.deserializeUser((obj, done) => {
    done(null, obj);
});

// Routes
app.get('/', (req, res) => {
    res.render('index');
});

// Initiate Google OAuth flow
app.get('/auth/google', passport.authenticate('google', {
    scope: ['profile', 'email'],
    prompt: 'select_account'
}));

// Handle OAuth callback
app.get('/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/' }),
    (req, res) => {
        res.redirect('/profile');
    }
);

// Profile route (protected)
app.get('/profile', (req, res) => {
    if (!req.isAuthenticated()) {
        return res.redirect('/auth/google');
    }
    res.render('profile', { user: req.user });
});

// Logout route
app.get('/logout', (req, res, next) => {
    req.logout(err => {
        if (err) return next(err);
        res.redirect('/');
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});